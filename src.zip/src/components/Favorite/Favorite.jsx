import React from 'react';
import './favorite.css'

const Favorite = () => {
    return (
        <div>
            <h1>收藏頁面</h1>
        </div>
    );
}

export default Favorite;
